#define SECRET_SSID ""
#define SECRET_PASS ""

// from https://developer.twitter.com/en/apps
#define SECRET_CONSUMER_KEY        ""
#define SECRET_CONSUMER_KEY_SECRET ""
#define SECRET_ACCESS_TOKEN        ""
#define SECRET_ACCESS_TOKEN_SECRET ""
